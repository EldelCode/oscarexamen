import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OscarModule } from './oscar/oscar.module';

@Module({
  imports: [OscarModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
