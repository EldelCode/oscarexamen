import { Module } from '@nestjs/common';
import { OscarController } from './oscar.controller';

@Module({
  controllers: [OscarController]
})
export class OscarModule {}
