import { Controller, Get, Render } from '@nestjs/common';

@Controller('oscar')
export class OscarController {
    @Get ()
    @Render ("oscarviews")
    Route (){}
}
